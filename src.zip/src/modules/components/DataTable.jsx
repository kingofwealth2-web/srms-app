export default function DataTable({ columns, data, onRow }) {
  return (
    <div style={{ overflowX: 'auto', marginInline: -2 }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 500 }}>
        <thead>
          <tr>
            {columns.map(c => (
              <th key={c.key} style={{
                padding: '9px 16px',
                textAlign: 'left',
                fontSize: 10, fontWeight: 700, color: 'var(--mist3)',
                textTransform: 'uppercase', letterSpacing: '0.1em',
                whiteSpace: 'nowrap',
                fontFamily: "'Clash Display',sans-serif",
                borderBottom: '1px solid var(--line)',
                background: 'transparent',
              }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 && (
            <tr>
              <td colSpan={columns.length} style={{
                padding: '52px 20px', textAlign: 'center',
                color: 'var(--mist3)', fontSize: 13,
              }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                  <div style={{ fontSize: 28, opacity: 0.3 }}>◌</div>
                  <span>No records found</span>
                </div>
              </td>
            </tr>
          )}
          {data.map((row, i) => (
            <tr
              key={row.id || i}
              onClick={() => onRow && onRow(row)}
              style={{
                borderBottom: '1px solid var(--line)',
                cursor: onRow ? 'pointer' : 'default',
                transition: 'background var(--t-snap)',
                animation: `fadeIn 0.3s ${i * 0.025}s both`,
              }}
              onMouseEnter={e => {
                if (onRow) e.currentTarget.style.background = 'rgba(255,255,255,0.025)'
              }}
              onMouseLeave={e => { e.currentTarget.style.background = 'transparent' }}
            >
              {columns.map(c => (
                <td key={c.key} style={{
                  padding: '13px 16px', fontSize: 13,
                  color: 'var(--white)', verticalAlign: 'middle',
                }}>
                  {c.render ? c.render(row[c.key], row) : (row[c.key] ?? '—')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}